﻿// these three variables are used by calendar.js

var selYear = 0;
var selMonth = 0;
var selDay = 0;
